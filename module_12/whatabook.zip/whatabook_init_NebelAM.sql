/*
Anthony Nebel 
10 May 2021
Module 12
What A Book Init Script
*/
/*
NOTE: Use these scripts if you need before running the scripts below

-- use this if the whatabook db doesnt exist 
CREATE DATABASE whatabook;

-- you must use the DB before running any of the below scripts
USE whatabook;
*/
CREATE DATABASE IF NOT EXISTS whatabook;

USE whatabook;

DROP USER IF EXISTS 'whatabook_user'@'localhost';

CREATE USER 'whatabook_user'@'localhost' IDENTIFIED WITH mysql_native_password BY 'MySQL8IsGreat!';

GRANT ALL PRIVILEGES ON whatabook.* TO 'whatabook_user'@'localhost';

-- ALTER TABLE wishlist DROP FOREIGN KEY fk_book;
-- ALTER TABLE wishlist DROP FOREIGN KEY fk_user;

DROP TABLE IF EXISTS store;
DROP TABLE IF EXISTS book;
DROP TABLE IF EXISTS wishlist;
DROP TABLE IF EXISTS user; 

CREATE TABLE store (
	store_id INT NOT NULL AUTO_INCREMENT, 
    locale VARCHAR(500) NOT NULL,
    PRIMARY KEY(store_id));

CREATE TABLE book (
	book_id INT NOT NULL AUTO_INCREMENT,
    book_name VARCHAR(200) NOT NULL, 
    author VARCHAR(200) NOT NULL,
    details VARCHAR(500), 
    PRIMARY KEY(book_id));
    
CREATE TABLE user (
	user_id INT NOT NULL AUTO_INCREMENT,
    first_name VARCHAR(75) NOT NULL,
    last_name VARCHAR(75) NOT NULL, 
    PRIMARY KEY(user_id));

CREATE TABLE wishlist (
	wishlist_id INT NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL,
    book_id INT NOT NULL,
    PRIMARY KEY(wishlist_id),
    CONSTRAINT fk_book FOREIGN KEY (book_id) REFERENCES book(book_id),
    CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES user(user_id));


-- Book records
INSERT INTO book (book_name, author, details)
	VALUES ('The Return of the King', 'J.R. Tolkien', 'The third part of the Lord of the Rings');

INSERT INTO book (book_name, author, details)
	VALUES ('The Fellowship of the Ring', 'J.R. Tolkien', 'The first part of the Lord of the Rings');

INSERT INTO book (book_name, author, details)
	VALUES ('The Two Towers', 'J.R. Tolkien', 'The second part of the Lord of the Rings');

INSERT INTO book (book_name, author)
	VALUES ('The Hobbit or There and Back Again', 'J.R. Tolkien');

INSERT INTO book (book_name, author)
	VALUES ('Dune: Deluxe Edition', 'Frank Herbert');
    
INSERT INTO book (book_name, author)
	VALUES ("Charlotte's Web", 'E.B. White');

INSERT INTO book (book_name, author)
	VALUES ('The Great Gatsby', 'F. Scott Fitzgerald');
    
INSERT INTO book (book_name, author)
	VALUES ('The Lion, the Witch, and the Wardrobe', 'C.S. Lewis');
    
INSERT INTO book (book_name, author)
	VALUES ('The Catcher and the Rye', 'J.D. Salinger');

-- User Records
INSERT INTO user  (first_name, last_name)
	VALUES ('Thorin', 'Oakenshield');
    
INSERT INTO user (first_name, last_name)
	VALUES ('Bilbo', 'Baggins');
    
INSERT INTO user (first_name, last_name)
	VALUES ('Frodo', 'Baggins');

-- Wishlist Records
INSERT INTO wishlist (user_id, book_id)
	VALUES ((SELECT user_id FROM user WHERE first_name = 'Thorin'),
    (SELECT book_id FROM book WHERE book_name = 'The Hobbit or There and Back Again'));

INSERT INTO wishlist (user_id, book_id)
	VALUES ((SELECT user_id FROM user WHERE first_name = 'Bilbo'),
    (SELECT book_id FROM book WHERE book_name = 'The Fellowship of the Ring'));
    
INSERT INTO wishlist (user_id, book_id)
	VALUES ((SELECT user_id FROM user WHERE first_name = 'Frodo'),
    (SELECT book_id FROM book WHERE book_name = 'The Return of the King'));
    
-- Store Record
INSERT INTO store (locale) VALUES ('1000 Galvin Rd S, Bellevue, NE, 68005, Mon-Fri: 8am-7pm Sat: 9am-4pm');
    
    
    

    
    





